# miaomiao OS
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://github.com/FoxerLee/miaomiao-OS/blob/master/LICENSE)
[![BCH compliance](https://bettercodehub.com/edge/badge/FoxerLee/miaomiao-OS?branch=master)](https://bettercodehub.com/)

- Version: 0.8.3-alpha
- Team member: Yuan Li, Kefei Wu
- Development environment: Liunx ubuntu 14.04, bochs 2.4.6
